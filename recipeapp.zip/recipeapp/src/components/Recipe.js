import React, { useState } from 'react';


export default function Recipe(){
	const[copy,setcopy]=useState("Procedure")
	const[recipe,setrecipe]= useState([
		
		{ 
			
		  name: 'Aloo Paratha',
		  description: 'To make delicious Aloo Parathas, boil the potatoes at least a few hours before you plan to make the parathas, mash them in a large bowl and cover and refrigerate. Take them out from the fridge and add chopped onions, coriander leaves, salt, garam masala powder and red chilli powder. Mix well so that no lumps remain. Ensure that you have finely chopped the onions or the filling will fall out. Put wheat flour in a large mixing bowl. Add water gradually and knead into a soft dough. Make small-medium balls of the dough and roll them out into 3 to 4-inch circles. Add a spoonful of potato filling in the centre. Gradually press the rolling pin on all sides while making the parathas. Be very careful to apply pressure evenly. It is very important to ensure that your potato mixture is mashed well and not lumpy or you will never be able to make perfect parathas. Seal the dough and round it with your fingers. Now, roll them with a rolling pin into round parathas. Apply the pressure very evenly and gently on all sides. Press very lightly so that the mixture does not come out. Heat an iron tawa and roast the parathas, cooking them on both sides with a spoonful of ghee. If you want to use less ghee on the parathas, first roast them on both sides on low flame and when they are slightly crispy, apply ghee with a kitchen brush on both sides. You must keep the flame low. Serve piping hot parathas with chilled yoghurt or pickle. You can also serve the aloo parathas with green chutney or coconut chutney or a light gravy. Ideally, a light potato shorba goes best with aloo ka paratha. You can also make quick onion-tomato-green chilli raita that tastes amazing with this paratha.',
		 image:"https://www.indianhealthyrecipes.com/wp-content/uploads/2021/06/aloo-paratha.jpg",
		},

        
		{ 
			
		  name: 'Kaju Barfi',
		  description: 'To make this traditional sweet dish at home, you need to begin with preparing the cashew nut powder. Take 1 1/2 cup cashew nuts and grind them, make sure you dont grind them too much as the cashews might release the oil, which can make the powder coarse. Then using a sieve, extract the fine powder and keep it aside.In the meantime, heat a pan over medium flame and add water along with sugar. Keep stirring till the sugar starts dissolving. Once the blend starts boiling, reduce the flame and add the fine cashew nut powder. Keep stirring and make sure the blend is smooth and has a slightly thick consistency. If you are fond of ghee, add some ghee to this mixture, this will add a nice taste and aroma to this dish. Keep stirring and add cardamom powder. Once this mixture is thick enough, turn off the flame and keep it aside.Transfer the Kaju katli mixture to a bowl and knead it into a fine smooth dough. Make sure that the Kaju katli dough is smooth and crack-free. Take a tray and grease it with ghee. Then transfer the sweet dough and flatten it using a rolling pin. Apply the silver varq and let it set for some time.Now, cut the Kaju Katli in the classic diamond shape and impress your loved ones with this delicious sweet.',
		 image:"http://www.indobase.com/recipes/rec-images/kaju-katli.jpg",
		},
		{ 
			
			name: 'Rasmalai',
			description: 'To prepare this easy sweet recipe from a scratch, you need to begin with making the chenna at home. Take a deep bottomed saucepan and boil 1 1/2 litres of milk at a high flame. Once the milk starts boiling, turn off the flame. Mix water with lemon juice and add into the hot milk. Once the milk starts crumbling, drain out the excess water using a muslin cloth and tightly tie the crumbled milk extracts in the cloth. Put it aside for 15-20 minutes.Take a deep bottomed pan and boil the remaining milk in it. Once the milk starts boiling, add saffron in it along with chopped pistachios and almonds. Allow this milk blend to attain a slightly thick consistency for about 5-7 minutes. Now, add 1 cup sugar in it and mix well. Once the milk blend is reduced to half, turn off the flame and transfer it to a bowl.Now, add the sugar syrup in a bowl filled with ice cubes. Add the rasmalai in this hot-cold sugar syrup one by one. Keep them in it for 2 minutes and then squeeze the extra water and add the rasmalai in saffron milk. Let the rasmalai soak for 3-4 hours to absorb the creamy texture of the milk. It tastes best when served chilled! ',
		   image:"https://www.cookwithmanali.com/wp-content/uploads/2014/07/Rasmalai-Recipe.jpg",
		  }
	  ])

	  let getDetails=(id)=>{
		  let z=recipe[id]
		  
		  setcopy(z.description)
		  
	  }


	  return (

		  
		<div >
		<div >
			<div  >
				{
					recipe.map((val, idx) => {
						return <div onClick={() => { getDetails(idx) }}><img  src={val.image} key={idx} width={100} />
							<div >
								<h4 >{val.name}</h4>
							</div>
						</div>
					})
				}
			</div>
			<div >
				<h5>{copy}</h5>
			</div>
		</div>
	</div>
)
}


