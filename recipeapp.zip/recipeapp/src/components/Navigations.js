import React from 'react'

export default function Navigation() {
    return (
        <nav >
            <div >
                <div >
                    <h2> <em><strong>Recipe-Plaza</strong></em></h2>
                </div>
            </div>
        </nav>
    )
}

