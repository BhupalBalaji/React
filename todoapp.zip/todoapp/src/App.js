import './App.css';
import ToDoApp from './components/ToDoApp';

function App() {
  return (<div>
    <h1>ToDoApp</h1>
    <ToDoApp/>
    
    </div>
  );
}

export default App;